import express from "express";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";
import rateLimit from "express-rate-limit";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "").toLowerCase().trim();
const API_KEY = process.env.OPENAI_API_KEY;
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET in .env to a random string of at least 32 characters.");
  process.exit(1);
}
app.disable("x-powered-by");
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));
const DB_PATH = process.env.DB_PATH || (process.env.VERCEL ? "/tmp/youssef-ai.sqlite" : path.join(__dirname, "data.sqlite"));
fs.mkdirSync(path.dirname(path.resolve(DB_PATH)), { recursive: true });
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS conversations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 title TEXT NOT NULL,
 messages TEXT NOT NULL DEFAULT '[]',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
`);
const authLimit = rateLimit({ windowMs: 15 * 60 * 1000, limit: 25, standardHeaders: true, legacyHeaders: false });
const aiLimit = rateLimit({ windowMs: 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false });
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = new Set(["application/pdf","text/plain","text/markdown","text/csv","application/json","image/png","image/jpeg","image/webp"]);
    cb(allowed.has(file.mimetype) ? null : new Error("Unsupported file type. Use PDF, TXT, MD, CSV, JSON, PNG, JPG, or WEBP."), allowed.has(file.mimetype));
  }
});
function tokenFor(user) {
  return jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: "7d", issuer: "youssef-ai" });
}
function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  try {
    if (!token) throw new Error("missing");
    const payload = jwt.verify(token, JWT_SECRET, { issuer: "youssef-ai" });
    const user = db.prepare("SELECT id,name,email,role,created_at FROM users WHERE id=?").get(payload.sub);
    if (!user) throw new Error("missing user");
    req.user = user; next();
  } catch { res.status(401).json({ error: "سجّل دخولك الأول." }); }
}
function admin(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "الصفحة دي للمدير فقط." });
  next();
}
async function openAI(pathname, body) {
  if (!API_KEY || API_KEY === "your_api_key_here") {
    const e = new Error("أضف مفتاح OpenAI API في ملف .env لتشغيل الذكاء الاصطناعي.");
    e.status = 503; throw e;
  }
  const response = await fetch(`https://api.openai.com/v1/${pathname}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const e = new Error(data?.error?.message || "تعذر الاتصال بخدمة الذكاء الاصطناعي.");
    e.status = response.status >= 500 ? 502 : response.status;
    throw e;
  }
  return data;
}
app.post("/api/auth/register", authLimit, async (req, res) => {
  try {
    const name = String(req.body.name || "").trim().slice(0, 60);
    const email = String(req.body.email || "").trim().toLowerCase().slice(0, 254);
    const password = String(req.body.password || "");
    if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 10) {
      return res.status(400).json({ error: "اكتب اسمًا وبريدًا صحيحًا وكلمة مرور 10 أحرف على الأقل." });
    }
    const role = ADMIN_EMAIL && email === ADMIN_EMAIL ? "admin" : "user";
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)").run(name,email,hash,role);
    const user = db.prepare("SELECT id,name,email,role,created_at FROM users WHERE id=?").get(result.lastInsertRowid);
    res.json({ token: tokenFor(user), user });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "البريد الإلكتروني مستخدم بالفعل." });
    res.status(500).json({ error: "حصل خطأ أثناء إنشاء الحساب." });
  }
});
app.post("/api/auth/login", authLimit, async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const row = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!row || !(await bcrypt.compare(password, row.password_hash))) return res.status(401).json({ error: "البريد أو كلمة المرور غير صحيحة." });
  const user = { id: row.id, name: row.name, email: row.email, role: row.role, created_at: row.created_at };
  res.json({ token: tokenFor(user), user });
});
app.get("/api/me", auth, (req,res) => res.json({ user: req.user }));
app.get("/api/conversations", auth, (req,res) => {
  const rows = db.prepare("SELECT id,title,created_at FROM conversations WHERE user_id=? ORDER BY id DESC LIMIT 50").all(req.user.id);
  res.json({ conversations: rows });
});
app.get("/api/conversations/:id", auth, (req,res) => {
  const row = db.prepare("SELECT id,title,messages,created_at FROM conversations WHERE id=? AND user_id=?").get(Number(req.params.id),req.user.id);
  if (!row) return res.status(404).json({ error: "المحادثة مش موجودة." });
  res.json({ conversation: { ...row, messages: JSON.parse(row.messages) } });
});
app.delete("/api/conversations/:id", auth, (req,res) => {
  db.prepare("DELETE FROM conversations WHERE id=? AND user_id=?").run(Number(req.params.id),req.user.id);
  res.json({ ok: true });
});
app.post("/api/chat", auth, aiLimit, async (req,res) => {
  try {
    const message = String(req.body.message || "").trim().slice(0, 12000);
    const history = Array.isArray(req.body.history) ? req.body.history.slice(-12).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 6000)
    })) : [];
    if (!message) return res.status(400).json({ error: "اكتب رسالتك الأول." });
    const data = await openAI("responses", {
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "You are YOUSSEF AI, a helpful, accurate assistant. Reply in the language used by the user. Be clear and honest about uncertainty.",
      input: [...history, { role: "user", content: message }]
    });
    const answer = data.output_text || "مش قادر أطلع رد دلوقتي، جرّب تاني.";
    const title = message.replace(/\s+/g," ").slice(0,70) || "محادثة جديدة";
    const result = db.prepare("INSERT INTO conversations(user_id,title,messages) VALUES(?,?,?)")
      .run(req.user.id, title, JSON.stringify([...history,{role:"user",content:message},{role:"assistant",content:answer}]));
    res.json({ answer, conversationId: Number(result.lastInsertRowid) });
  } catch (e) { res.status(e.status || 500).json({ error: e.message || "حصل خطأ غير متوقع." }); }
});
app.post("/api/analyze-file", auth, aiLimit, upload.single("file"), async (req,res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "اختار ملفًا مدعومًا." });
    const question = String(req.body.question || "لخّص الملف واشرح أهم النقاط.").slice(0,3000);
    const b64 = req.file.buffer.toString("base64");
    const content = [{ type: "input_text", text: question }];
    if (req.file.mimetype.startsWith("image/")) {
      content.unshift({ type:"input_image", image_url:`data:${req.file.mimetype};base64,${b64}`, detail:"auto" });
    } else {
      content.unshift({ type:"input_file", filename:req.file.originalname.replace(/[^\w.\- ()]/g,"_").slice(0,100) || "upload", file_data:`data:${req.file.mimetype};base64,${b64}` });
    }
    const data = await openAI("responses", { model: process.env.OPENAI_MODEL || "gpt-4.1-mini", input:[{role:"user",content}] });
    res.json({ answer: data.output_text || "لم أتمكن من تحليل الملف." });
  } catch (e) { res.status(e.status || 500).json({ error: e.message || "تعذر تحليل الملف." }); }
});
app.post("/api/image", auth, aiLimit, async (req,res) => {
  try {
    const prompt = String(req.body.prompt || "").trim().slice(0,2000);
    if (!prompt) return res.status(400).json({ error: "اكتب وصف الصورة." });
    const data = await openAI("responses", {
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      input: prompt,
      tools: [{ type:"image_generation", model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2", size:"1024x1024" }]
    });
    const item = (data.output || []).find(x => x.type === "image_generation_call" && x.result);
    if (!item) return res.status(502).json({ error: "الخدمة لم تُرجع صورة. جرّب وصفًا آخر." });
    res.json({ image: `data:image/png;base64,${item.result}` });
  } catch (e) { res.status(e.status || 500).json({ error: e.message || "تعذر إنشاء الصورة." }); }
});
app.get("/api/admin/stats", auth, admin, (_req,res) => {
  const users = db.prepare("SELECT COUNT(*) AS n FROM users").get().n;
  const conversations = db.prepare("SELECT COUNT(*) AS n FROM conversations").get().n;
  const recent = db.prepare("SELECT id,name,email,role,created_at FROM users ORDER BY id DESC LIMIT 30").all();
  res.json({ users, conversations, recent });
});
app.use((err, _req, res, _next) => {
  const message = err instanceof multer.MulterError ? "الملف أكبر من الحد المسموح (10 ميجابايت)." : (err.message || "حصل خطأ.");
  res.status(400).json({ error: message });
});
app.get("*", (_req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
if (process.env.VERCEL) {
  // Vercel detects this default export and runs the Express app as a Function.
  // Note: /tmp is ephemeral; use a hosted database for durable accounts/conversations.
} else {
  app.listen(PORT, () => console.log(`YOUSSEF AI is running on http://localhost:${PORT}`));
}

export default app;
