const $ = (id) => document.getElementById(id);
let token = localStorage.getItem("yai_token") || "";
let user = null, authMode = "login", currentView = "chat", activeConversation = null, currentMessages = [];
const labels = {chat:"الدردشة الذكية",image:"إنشاء الصور",files:"تحليل الملفات",admin:"لوحة الإدارة"};
function toast(msg){$("toast").textContent=msg;$("toast").classList.remove("hidden");setTimeout(()=>$("toast").classList.add("hidden"),3500)}
async function api(url, options={}) {
  const headers = {...(options.headers||{})};
  if(token) headers.Authorization = `Bearer ${token}`;
  if(options.body && !(options.body instanceof FormData)) headers["Content-Type"]="application/json";
  const r=await fetch(url,{...options,headers});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||"حصل خطأ في الاتصال.");
  return data;
}
function setView(view){
  if(view==="admin" && user?.role!=="admin"){toast("لوحة الإدارة للمدير فقط.");return}
  currentView=view;
  document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));
  $(`${view}View`).classList.add("active");
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.view===view));
  $("crumb").innerHTML=`${labels[view]} <span> / </span> <b>${view==="chat"?"محادثة جديدة":"مساحة العمل"}</b>`;
  $("sidebar").classList.remove("open");
}
function updateAuthUI(){
  $("authBtn").classList.toggle("hidden",!!user);
  $("userBadge").classList.toggle("hidden",!user);
  $("userBadge").textContent=user?`👤 ${user.name}`:"";
  $("adminNav").classList.toggle("hidden",user?.role!=="admin");
  if(!user) $("history").innerHTML="";
  if(user) loadHistory();
}
async function refreshUser(){if(!token)return;try{const d=await api("/api/me");user=d.user;updateAuthUI()}catch{token="";localStorage.removeItem("yai_token")}}
function openAuth(mode="login") { authMode=mode; $("authError").textContent=""; $("authModal").classList.remove("hidden"); renderAuthMode(); }
function renderAuthMode(){
  const register=authMode==="register";
  $("modalTitle").textContent=register?"اعمل حساب جديد":"أهلًا بعودتك";
  $("modalSub").textContent=register?"أنشئ حسابك وابدأ استخدام YOUSSEF AI.":"سجّل دخولك عشان تبدأ محادثاتك.";
  $("nameField").classList.toggle("hidden",!register);
  $("authName").required=register;
  $("authPassword").autocomplete=register?"new-password":"current-password";
  $("authSubmit").textContent=register?"إنشاء الحساب":"تسجيل الدخول";
  $("switchAuth").textContent=register?"عندك حساب؟ سجّل دخولك":"معندكش حساب؟ اعمل حساب جديد";
}
function addMessage(role,content){
  $("welcome").classList.add("hidden");$("messages").classList.remove("hidden");
  const row=document.createElement("div");row.className=`message ${role}`;
  const av=document.createElement("div");av.className="avatar";av.textContent=role==="assistant"?"✦":"أنت";
  const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=content;
  row.append(av,bubble);$("messages").appendChild(row);row.scrollIntoView({behavior:"smooth",block:"end"});
}
function resetChat(){
  activeConversation=null;currentMessages=[];$("messages").innerHTML="";$("messages").classList.add("hidden");$("welcome").classList.remove("hidden");
  $("crumb").innerHTML='الدردشة الذكية <span> / </span> <b>محادثة جديدة</b>';
  $("chatInput").value="";
}
async function sendChat(textOverride){
  const message=(textOverride ?? $("chatInput").value).trim();if(!message)return;
  if(!user){openAuth();toast("سجّل دخولك عشان تستخدم الشات وتحفظ محادثاتك.");return}
  $("chatInput").value="";$("sendBtn").disabled=true;
  addMessage("user",message);currentMessages.push({role:"user",content:message});
  const placeholder=document.createElement("div");placeholder.className="message assistant";placeholder.id="typing";
  placeholder.innerHTML='<div class="avatar">✦</div><div class="bubble">بفكّر في إجابة مناسبة…</div>';$("messages").appendChild(placeholder);
  try{
    const d=await api("/api/chat",{method:"POST",body:JSON.stringify({message,history:currentMessages.slice(0,-1)})});
    $("typing")?.remove();addMessage("assistant",d.answer);currentMessages.push({role:"assistant",content:d.answer});activeConversation=d.conversationId;await loadHistory();
  }catch(e){$("typing")?.remove();addMessage("assistant",`حصلت مشكلة: ${e.message}`)}
  finally{$("sendBtn").disabled=false;$("chatInput").focus()}
}
async function loadHistory(){
  if(!user)return;
  try{const d=await api("/api/conversations");$("history").innerHTML="";
    d.conversations.forEach(c=>{const b=document.createElement("button");b.textContent=c.title;b.title=c.title;b.onclick=()=>openConversation(c.id);$("history").appendChild(b)});
  }catch{}
}
async function openConversation(id){
  try{const d=await api(`/api/conversations/${id}`);activeConversation=id;currentMessages=d.conversation.messages||[];$("messages").innerHTML="";$("welcome").classList.add("hidden");$("messages").classList.remove("hidden");currentMessages.forEach(m=>addMessage(m.role,m.content));$("crumb").innerHTML=`الدردشة الذكية <span> / </span> <b>${d.conversation.title}</b>`;setView("chat")}catch(e){toast(e.message)}
}
async function submitAuth(ev){
  ev.preventDefault();$("authError").textContent="";
  const body={email:$("authEmail").value,password:$("authPassword").value};
  if(authMode==="register")body.name=$("authName").value;
  try{
    const d=await api(`/api/auth/${authMode}`,{method:"POST",body:JSON.stringify(body)});
    token=d.token;user=d.user;localStorage.setItem("yai_token",token);$("authModal").classList.add("hidden");$("authForm").reset();updateAuthUI();toast("تم تسجيل الدخول بنجاح."); 
  }catch(e){$("authError").textContent=e.message}
}
async function generateImage(){
  const prompt=$("imagePrompt").value.trim();if(!prompt)return toast("اكتب وصف الصورة الأول.");
  if(!user)return openAuth();
  $("generateBtn").disabled=true;$("generateBtn").textContent="جاري إنشاء الصورة...";
  $("imageResult").textContent="قد يستغرق إنشاء الصورة بعض الوقت.";
  try{const d=await api("/api/image",{method:"POST",body:JSON.stringify({prompt})});$("imageResult").innerHTML="";
    const img=document.createElement("img");img.src=d.image;img.alt=prompt;$("imageResult").appendChild(img);
    const a=document.createElement("a");a.className="download-link";a.href=d.image;a.download="youssef-ai-image.png";a.textContent="تنزيل الصورة";$("imageResult").appendChild(a);
  }catch(e){$("imageResult").textContent=e.message}
  finally{$("generateBtn").disabled=false;$("generateBtn").textContent="✧ أنشئ الصورة"}
}
async function analyzeFile(){
  const file=$("fileInput").files[0];if(!file)return toast("اختار ملفًا الأول.");
  if(!user)return openAuth();
  const fd=new FormData();fd.append("file",file);fd.append("question",$("fileQuestion").value||"لخّص الملف واشرح أهم النقاط.");
  $("analyzeBtn").disabled=true;$("analyzeBtn").textContent="جاري تحليل الملف...";
  $("fileResult").textContent="براجع محتوى الملف...";
  try{const d=await api("/api/analyze-file",{method:"POST",body:fd});$("fileResult").textContent=d.answer}
  catch(e){$("fileResult").textContent=e.message}
  finally{$("analyzeBtn").disabled=false;$("analyzeBtn").textContent="▧ حلّل الملف"}
}
async function loadAdmin(){
  $("adminResult").textContent="جاري تحميل الإحصائيات...";
  try{const d=await api("/api/admin/stats");$("adminResult").innerHTML="";
    const grid=document.createElement("div");grid.className="stat-grid";
    [[d.users,"عدد الحسابات"],[d.conversations,"عدد المحادثات"]].forEach(([n,label])=>{const el=document.createElement("div");el.className="stat";const small=document.createElement("small");small.textContent=label;const strong=document.createElement("strong");strong.textContent=n;el.append(small,strong);grid.append(el)});$("adminResult").append(grid);
    const table=document.createElement("table");table.className="user-table";table.innerHTML="<thead><tr><th>الاسم</th><th>البريد</th><th>الصلاحية</th></tr></thead>";
    const tbody=document.createElement("tbody");d.recent.forEach(u=>{const tr=document.createElement("tr");[u.name,u.email,u.role==="admin"?"مدير":"مستخدم"].forEach(v=>{const td=document.createElement("td");td.textContent=v;tr.append(td)});tbody.append(tr)});table.append(tbody);$("adminResult").append(table);
  }catch(e){$("adminResult").textContent=e.message}
}
$("sendBtn").onclick=()=>sendChat();$("chatInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendChat()}});
$("newChat").onclick=resetChat;$("authBtn").onclick=()=>openAuth();$("closeModal").onclick=()=>$("authModal").classList.add("hidden");
$("authModal").addEventListener("click",e=>{if(e.target===$("authModal"))$("authModal").classList.add("hidden")});
$("authForm").onsubmit=submitAuth;$("switchAuth").onclick=()=>{authMode=authMode==="login"?"register":"login";renderAuthMode();$("authError").textContent=""};
document.querySelectorAll("[data-view]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.view)));
document.querySelectorAll("[data-prompt]").forEach(b=>b.addEventListener("click",()=>sendChat(b.dataset.prompt)));
$("generateBtn").onclick=generateImage;$("analyzeBtn").onclick=analyzeFile;$("loadAdmin").onclick=loadAdmin;
$("fileInput").onchange=()=>{$("fileName").textContent=$("fileInput").files[0]?.name||"لم يتم اختيار ملف"};
$("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
refreshUser();
