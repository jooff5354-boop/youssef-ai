# YOUSSEF AI

مشروع بداية عملي لموقع ذكاء اصطناعي عربي RTL، متجاوب مع الموبايل، باستخدام Express وSQLite وOpenAI API.

## الموجود في المشروع
- واجهة عربية زرقاء، متجاوبة مع الهاتف والكمبيوتر.
- إنشاء حساب وتسجيل دخول بكلمات مرور مشفّرة.
- شات متصل بـ OpenAI Responses API وحفظ المحادثات في SQLite.
- تحليل ملفات PDF وTXT وMD وCSV وJSON وصور PNG/JPG/WEBP (حد الملف 10MB).
- إنشاء صور باستخدام أداة image generation في Responses API.
- لوحة إدارة تظهر للحساب الذي يطابق `ADMIN_EMAIL`.
- حدود طلبات أساسية على تسجيل الدخول وميزات AI.

## المتطلبات
- Node.js 20 أو أحدث (يفضل إصدار LTS).
- مفتاح API من منصة OpenAI مع تفعيل الفوترة/الرصيد المناسب. استخدام الـ API منفصل عن اشتراك ChatGPT وقد يترتب عليه تكلفة.

## التشغيل على الكمبيوتر
1. فك ضغط الملف.
2. افتح مجلد `youssef-ai` في الطرفية.
3. نفّذ `npm install`.
4. انسخ `.env.example` إلى ملف اسمه `.env`.
5. افتح `.env` واكتب `OPENAI_API_KEY`، وغيّر `JWT_SECRET` إلى قيمة عشوائية طويلة، واكتب بريدك في `ADMIN_EMAIL`.
6. نفّذ `npm start`.
7. افتح `http://localhost:3000`.

أول حساب يُسجّل بالبريد المطابق تمامًا لـ `ADMIN_EMAIL` يحصل على صلاحية مدير. سجّل هذا الحساب بنفسك أولًا ولا تشارك ملف `.env`.

## المتغيرات
- `OPENAI_API_KEY`: مفتاح API، يبقى على الخادم فقط ولا تضعه في ملفات `public`.
- `OPENAI_MODEL`: النموذج النصي الافتراضي `gpt-4.1-mini` ويمكن تغييره لنموذج متاح في حسابك.
- `OPENAI_IMAGE_MODEL`: نموذج الصور الافتراضي `gpt-image-2`؛ قد يتطلب صلاحيات/فوترة متاحة لحسابك.
- `JWT_SECRET`: سر جلسات المستخدمين، استخدم قيمة عشوائية قوية.
- `ADMIN_EMAIL`: البريد الذي يُمنح صلاحية المدير عند إنشاء الحساب.
- `PORT`: المنفذ (افتراضي 3000).

## نشره على الإنترنت
استخدم استضافة Node.js تدعم متغيرات البيئة وقرصًا دائمًا لحفظ `data.sqlite`. أضف المتغيرات في إعدادات الاستضافة، ثم اربط دومينًا وفعّل HTTPS. لا ترفع `.env` إلى GitHub. SQLite مناسبة لبداية صغيرة؛ عند الاستخدام الجاد أو عدة نسخ للخادم استخدم PostgreSQL ومخزن ملفات مناسبًا.

## ملاحظات أمنية مهمة قبل النشر العام
هذا مشروع بداية وليس تدقيقًا أمنيًا كاملًا. قبل نشره للجمهور:
- أضف تحقق بريد/استعادة كلمة مرور وسياسة خصوصية وشروط استخدام وحذف حساب/بيانات.
- استخدم HTTPS، وراجع إعدادات CORS والكوكيز/الجلسات، وأضف حماية CSRF إذا تحولت المصادقة إلى كوكيز.
- أضف حصص استخدام وتكلفة لكل مستخدم، ومراقبة، وحماية إساءة الاستخدام.
- قيّد أنواع الملفات وحجمها كما هو موجود، وراجع احتفاظك بالملفات والبيانات.
- لا تستخدم بيانات حقيقية حساسة في التجارب.
- تأكد أن نموذج الصور متاح في مشروع API الخاص بك. قد تختلف النماذج المتاحة حسب الحساب.

## نشر مُعدّ مسبقًا على Render
يتضمن المشروع ملف `render.yaml` لتسهيل إنشاء خدمة Node.js مع قرص دائم لقاعدة SQLite. عند ربط مستودع GitHub بـ Render واختيار Blueprint، راجع إعدادات الخدمة قبل التأكيد. الخطة المحددة `starter` مدفوعة لأن هذا الإعداد يحتاج قرصًا دائمًا؛ لا تستبدلها بخطة مجانية إذا كنت تريد حفظ الحسابات والمحادثات على القرص المحلي. ستُطلب منك قيم `OPENAI_API_KEY` و`ADMIN_EMAIL` أثناء الإعداد. تم توليد `JWT_SECRET` تلقائيًا بواسطة Render Blueprint. بعد النشر، افتح الرابط وأنشئ حسابًا بالبريد الذي وضعته في `ADMIN_EMAIL` ليكون حساب المدير.


## Vercel deployment (important)

This project can be detected as an Express app by Vercel because `server.js` exports the app. Put the project in a Git repository and import it at Vercel. Add these Environment Variables in Project Settings → Environment Variables:

- `OPENAI_API_KEY`: your secret OpenAI API key (never put it in frontend files)
- `JWT_SECRET`: a long random secret, at least 32 characters
- `ADMIN_EMAIL`: the email address that should receive admin privileges
- `OPENAI_MODEL`: `gpt-4.1-mini` (or a model available to your API account)
- `OPENAI_IMAGE_MODEL`: `gpt-image-1` (if enabled for your API account)

**Database warning:** the current version uses SQLite, and on Vercel it is placed in `/tmp` only to avoid writes to the read-only deployment filesystem. `/tmp` is temporary and can be cleared or differ between function instances, so users and conversations are NOT guaranteed to persist. For a public production site, replace SQLite with a hosted database (such as a managed Postgres service) before relying on accounts/admin data.

Vercel serves files in `public/` as static assets; the Express function handles `/api/*` routes.
